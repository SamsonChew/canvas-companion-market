#!/bin/bash
# Canvas Companion for ChatGPT / Codex — double-click menu (install, update,
# change licence key / Canvas token / Canvas address, uninstall).
#
# Shipped inside codex/CanvasCompanion-ChatGPT-安装.zip in the marketplace repo
# (plugin/build/make_marketplace.sh renders SamsonChew/canvas-companion-market and zips it
# with the executable bit set), so a student double-clicks it in Finder instead
# of pasting a command into Terminal. It holds no installer logic of its own:
#
#   1. downloads codex/install.sh (or uninstall.sh) and its .sha256 from the
#      marketplace repo — the same file the one-line curl command runs
#   2. checks the SHA-256 against the published one (catches a truncated or
#      mangled download, e.g. a Wi-Fi login page; it is not a signature — both
#      files come from the same repo) and stops on a mismatch
#   3. runs it from the home folder with the flag for the chosen menu item
#
# Optional argument (tests, or a second copy with a fixed action): the menu
# item, as its number or its name (install, set-license, set-token, set-domain,
# uninstall). Without it the menu asks; Return alone = install / update.
set -u
PATH="${PATH:+$PATH:}/usr/bin:/bin:/usr/sbin:/sbin"
BASE="https://raw.githubusercontent.com/SamsonChew/canvas-companion-market/main/codex"

say() { printf '%s\n' "$*"; }
ask() { printf '%s' "$1"; IFS= read -r REPLY || REPLY=""; }  # prompt shows even without a tty
finish() {  # exit code
  say ""
  if [[ $1 == 0 ]]; then
    say "✓ 完成 / done."
  else
    say "✗ 没有完成（代码 $1）。把这个窗口截图发给作者。"
    say "  Not finished (code $1). Send a screenshot of this window to the author."
  fi
  say ""
  ask "按回车关闭窗口 / press Return to close this window "
  exit "$1"
}

cat <<'BANNER'

  ============================================================
    Canvas Companion · ChatGPT 版 / for ChatGPT (Codex)
  ============================================================
  先退出 ChatGPT App（⌘ + Q）。/ Quit the ChatGPT app first (⌘ + Q).

    1  安装或更新          install or update   （直接回车 / Return）
    2  更换授权码          change licence key
    3  更换 Canvas 令牌    change Canvas token
    4  更换 Canvas 网址    change Canvas address
    5  卸载                uninstall

BANNER

choice="${1:-}"
if [[ -z "$choice" ]]; then
  ask "输入数字后按回车 / type a number, then Return [1]: "; choice="$REPLY"
fi
choice="$(printf '%s' "$choice" | tr -d '[:space:]')"
case "$choice" in
  ""|1|install)     SCRIPT=install.sh;   FLAG="" ;;
  2|set-license)    SCRIPT=install.sh;   FLAG="--set-license" ;;
  3|set-token)      SCRIPT=install.sh;   FLAG="--set-token" ;;
  4|set-domain)     SCRIPT=install.sh;   FLAG="--set-domain" ;;
  5|uninstall)      SCRIPT=uninstall.sh; FLAG="" ;;
  *) say "没有这个选项：$choice / no such option."; finish 2 ;;
esac

if [[ $SCRIPT == uninstall.sh ]]; then
  say "卸载会从 ChatGPT App 移除 Canvas Companion，并删掉钥匙串里的 Canvas 令牌和授权码。"
  say "课程文件夹里的课件和笔记不会动。"
  say "Uninstalling removes Canvas Companion from the ChatGPT app and deletes the token and"
  say "licence key from the Keychain. Your course folder is left as it is."
  ask "确定卸载吗？输入 y 回车 / type y and Return to uninstall: "
  [[ "$REPLY" == y || "$REPLY" == Y ]] || { say "已取消，什么都没改 / cancelled, nothing changed."; finish 0; }
fi

TMP="$(mktemp -d "${TMPDIR:-/tmp}/canvas-companion-dl.XXXXXX")" || finish 1
trap 'rm -rf "$TMP"' EXIT

say ""
say "下载 / downloading $SCRIPT …"
if ! curl -fsSL --retry 2 "$BASE/$SCRIPT" -o "$TMP/$SCRIPT" \
   || ! curl -fsSL --retry 2 "$BASE/$SCRIPT.sha256" -o "$TMP/$SCRIPT.sha256"; then
  say "下载失败：检查网络后再双击一次。"
  say "Download failed — check your internet connection and double-click again."
  finish 3
fi

sha256() {
  if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1"; else sha256sum "$1"; fi \
    | awk '{print $1}'
}
want="$(awk 'NR == 1 {print tolower($1)}' "$TMP/$SCRIPT.sha256")"
got="$(sha256 "$TMP/$SCRIPT")"
if [[ ! "$want" =~ ^[0-9a-f]{64}$ || "$want" != "$got" ]]; then
  say "校验失败：下载的文件不完整或被改动过，没有运行。过几分钟再双击一次"
  say "（作者刚发布新版本时会这样）；还不行就截图发给作者。"
  say "Checksum mismatch: the download is incomplete or altered, so it was NOT run."
  say "Try again in a few minutes (this happens right after a new release)."
  finish 4
fi
say "✓ 校验通过 / checksum ok"

# From the home folder: a relative course-folder answer must not land in $TMP.
cd "$HOME" || finish 1
if [[ -n "$FLAG" ]]; then
  /bin/bash "$TMP/$SCRIPT" "$FLAG"
else
  /bin/bash "$TMP/$SCRIPT"
fi
finish $?
